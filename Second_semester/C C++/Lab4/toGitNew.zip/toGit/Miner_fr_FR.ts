<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fr_FR">
<context>
    <name>Board</name>
    <message>
        <location filename="Board.cpp" line="178"/>
        <location filename="Board.cpp" line="184"/>
        <source>Game Rules</source>
        <translation>Regles du jeu</translation>
    </message>
    <message>
        <location filename="Board.cpp" line="184"/>
        <source>Minesweeper Rules:

1. Uncover a mine, and the game ends.
2. Uncover an empty square, and you keep playing.
3. Uncover a number, and it tells you how many mines lay hidden in the eight surrounding squares.

Good luck!</source>
        <translation>Règles du dragueur de mines&#xa0;:

1. Découvrez une mine et le jeu se termine.
2. Découvrez une case vide et vous continuez à jouer.
3. Découvrez un chiffre qui vous indique combien de mines sont cachées dans les huit cases environnantes.

Bonne chance!</translation>
    </message>
    <message>
        <location filename="Board.cpp" line="437"/>
        <source>Game Over</source>
        <translation>Jeu terminé</translation>
    </message>
    <message>
        <location filename="Board.cpp" line="437"/>
        <source>You hit a bomb! Game over.</source>
        <translation>Vous avez frappé une bombe&#xa0;! Jeu terminé.</translation>
    </message>
    <message>
        <location filename="Board.cpp" line="454"/>
        <source>Congrats</source>
        <translation>Toutes nos félicitations</translation>
    </message>
    <message>
        <location filename="Board.cpp" line="454"/>
        <source>You won</source>
        <translation>Tu as gagné</translation>
    </message>
</context>
<context>
    <name>RestartWindow</name>
    <message>
        <location filename="RestartWindow.cpp" line="5"/>
        <source>Restart Game</source>
        <translation>Recommencer le jeu</translation>
    </message>
    <message>
        <location filename="RestartWindow.cpp" line="7"/>
        <source>Try Again</source>
        <translation>Essayer à nouveau</translation>
    </message>
    <message>
        <location filename="RestartWindow.cpp" line="10"/>
        <source>Go to Settings</source>
        <translation>Aller aux paramètres</translation>
    </message>
    <message>
        <location filename="RestartWindow.cpp" line="13"/>
        <source>Resume</source>
        <translation>Reprendre</translation>
    </message>
</context>
<context>
    <name>SettingsWindow</name>
    <message>
        <source>Change Language</source>
        <translation type="vanished">Changer de langue</translation>
    </message>
    <message>
        <location filename="SettingsWindow.cpp" line="46"/>
        <location filename="SettingsWindow.cpp" line="105"/>
        <source>Board Height</source>
        <translation>Hauteur de la planche</translation>
    </message>
    <message>
        <location filename="SettingsWindow.cpp" line="47"/>
        <location filename="SettingsWindow.cpp" line="106"/>
        <source>Board Width</source>
        <translation>Largeur de la planche</translation>
    </message>
    <message>
        <location filename="SettingsWindow.cpp" line="48"/>
        <location filename="SettingsWindow.cpp" line="107"/>
        <source>Bombs Quantity</source>
        <translation>Quantité de bombes</translation>
    </message>
    <message>
        <location filename="SettingsWindow.cpp" line="49"/>
        <location filename="SettingsWindow.cpp" line="108"/>
        <source>Language</source>
        <translation>Langue</translation>
    </message>
    <message>
        <location filename="SettingsWindow.cpp" line="32"/>
        <location filename="SettingsWindow.cpp" line="103"/>
        <source>Start</source>
        <translation>Commencer</translation>
    </message>
    <message>
        <location filename="SettingsWindow.cpp" line="39"/>
        <location filename="SettingsWindow.cpp" line="104"/>
        <source>Cancel</source>
        <translation>Annuler</translation>
    </message>
</context>
</TS>

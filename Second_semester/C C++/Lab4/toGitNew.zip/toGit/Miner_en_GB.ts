<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_GB">
<context>
    <name>Board</name>
    <message>
        <location filename="Board.cpp" line="178"/>
        <location filename="Board.cpp" line="184"/>
        <source>Game Rules</source>
        <translation>Game Rules</translation>
    </message>
    <message>
        <location filename="Board.cpp" line="184"/>
        <source>Minesweeper Rules:

1. Uncover a mine, and the game ends.
2. Uncover an empty square, and you keep playing.
3. Uncover a number, and it tells you how many mines lay hidden in the eight surrounding squares.

Good luck!</source>
        <translation>Minesweeper Rules:

1. Uncover a mine, and the game ends.
2. Uncover an empty square, and you keep playing.
3. Uncover a number, and it tells you how many mines lay hidden in the eight surrounding squares.

Good luck!</translation>
    </message>
    <message>
        <location filename="Board.cpp" line="437"/>
        <source>Game Over</source>
        <translation>Game over</translation>
    </message>
    <message>
        <location filename="Board.cpp" line="437"/>
        <source>You hit a bomb! Game over.</source>
        <translation>You hit a bomb! Game over.</translation>
    </message>
    <message>
        <location filename="Board.cpp" line="454"/>
        <source>Congrats</source>
        <translation>Congrats</translation>
    </message>
    <message>
        <location filename="Board.cpp" line="454"/>
        <source>You won</source>
        <translation>You won</translation>
    </message>
</context>
<context>
    <name>RestartWindow</name>
    <message>
        <location filename="RestartWindow.cpp" line="5"/>
        <source>Restart Game</source>
        <translation>Restart Game</translation>
    </message>
    <message>
        <location filename="RestartWindow.cpp" line="7"/>
        <source>Try Again</source>
        <translation>Try Again</translation>
    </message>
    <message>
        <location filename="RestartWindow.cpp" line="10"/>
        <source>Go to Settings</source>
        <translation>Go to Settings</translation>
    </message>
    <message>
        <location filename="RestartWindow.cpp" line="13"/>
        <source>Resume</source>
        <translation>Resume</translation>
    </message>
</context>
<context>
    <name>SettingsWindow</name>
    <message>
        <location filename="SettingsWindow.cpp" line="46"/>
        <location filename="SettingsWindow.cpp" line="105"/>
        <source>Board Height</source>
        <translation>Board Height</translation>
    </message>
    <message>
        <location filename="SettingsWindow.cpp" line="47"/>
        <location filename="SettingsWindow.cpp" line="106"/>
        <source>Board Width</source>
        <translation>Board Width</translation>
    </message>
    <message>
        <location filename="SettingsWindow.cpp" line="48"/>
        <location filename="SettingsWindow.cpp" line="107"/>
        <source>Bombs Quantity</source>
        <translation>Bombs Quantity</translation>
    </message>
    <message>
        <location filename="SettingsWindow.cpp" line="49"/>
        <location filename="SettingsWindow.cpp" line="108"/>
        <source>Language</source>
        <translation>Language</translation>
    </message>
    <message>
        <location filename="SettingsWindow.cpp" line="32"/>
        <location filename="SettingsWindow.cpp" line="103"/>
        <source>Start</source>
        <translation>Start</translation>
    </message>
    <message>
        <location filename="SettingsWindow.cpp" line="39"/>
        <location filename="SettingsWindow.cpp" line="104"/>
        <source>Cancel</source>
        <translation>Cancel</translation>
    </message>
</context>
</TS>

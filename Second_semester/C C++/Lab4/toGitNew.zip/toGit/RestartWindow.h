#pragma once

#include <QDialog>
#include <QPushButton>
#include <QTranslator>
#include <QVBoxLayout>

class RestartWindow : public QDialog
{
    Q_OBJECT

public:
    explicit RestartWindow(QWidget *parent = nullptr);

signals:
    void tryAgainClicked();
    void backToSettingsClicked();
    void resumeClicked();

private:
    QTranslator translator;
    QPushButton *tryAgainButton;
    QPushButton *goToSettingsButton;
    QPushButton *resumeButton;
};

#include "SettingsWindow.h"
#include "qlabel.h"

#include <QApplication>

SettingsWindow::SettingsWindow(QWidget *parent) : QDialog(parent)
{
    setWindowTitle("Settings");

    boardHeightSpinBox = new QSpinBox(this);
    boardHeightSpinBox->setRange(1, 30);
    boardHeightSpinBox->setValue(10);

    boardWidthSpinBox = new QSpinBox(this);
    boardWidthSpinBox->setRange(1, 30);
    boardWidthSpinBox->setValue(10);

    bombsQuantitySpinBox = new QSpinBox(this);
    bombsQuantitySpinBox->setRange(1, 899);
    bombsQuantitySpinBox->setValue(10);

    languageComboBox = new QComboBox(this);
    languageComboBox->addItem("Русский", "ru_RU");
    languageComboBox->addItem("English", "en_GB");
    languageComboBox->addItem("Deutsch", "de_DE");
    languageComboBox->addItem("Français", "fr_FR");
    languageComboBox->addItem("Español", "es_ES");
    languageComboBox->addItem("भारतीय", "hi_IN");
    connect(languageComboBox, QOverload< int >::of(&QComboBox::activated), this, &SettingsWindow::changeLanguage);

    startButton = new QPushButton(tr("Start"), this);
    connect(startButton,
            &QPushButton::clicked,
            [this]()
            {
                emit settingsLoaded(getBoardHeight(), getBoardWidth(), getBombsQuantity());
                emit accepted();
                close();
            });

    cancelButton = new QPushButton(tr("Cancel"), this);
    connect(cancelButton,
            &QPushButton::clicked,
            [this]()
            {
                emit rejected();
                close();
            });

    QVBoxLayout *layout = new QVBoxLayout(this);
    boardHeight = new QLabel(tr("Board Height") + ":", this);
    boardWidth = new QLabel(tr("Board Width") + ":", this);
    bombsQuantity = new QLabel(tr("Bombs Quantity") + ":", this);
    language = new QLabel(tr("Language") + ":", this);
    layout->addWidget(boardHeight);
    layout->addWidget(boardHeightSpinBox);
    layout->addWidget(boardWidth);
    layout->addWidget(boardWidthSpinBox);
    layout->addWidget(bombsQuantity);
    layout->addWidget(bombsQuantitySpinBox);
    layout->addWidget(language);
    layout->addWidget(languageComboBox);
    layout->addWidget(startButton);
    layout->addWidget(cancelButton);

    setLayout(layout);

    connect(boardHeightSpinBox, SIGNAL(valueChanged(int)), this, SLOT(updateBombsQuantityLimit()));
    connect(boardWidthSpinBox, SIGNAL(valueChanged(int)), this, SLOT(updateBombsQuantityLimit()));

    updateBombsQuantityLimit();
}

void SettingsWindow::updateBombsQuantityLimit()
{
    int maxBombs = boardHeightSpinBox->value() * boardWidthSpinBox->value() - 1;
    bombsQuantitySpinBox->setMaximum(maxBombs);

    if (bombsQuantitySpinBox->value() > maxBombs)
    {
        bombsQuantitySpinBox->setValue(maxBombs);
    }
}

int SettingsWindow::getBoardHeight() const
{
    return boardHeightSpinBox->value();
}

int SettingsWindow::getBoardWidth() const
{
    return boardWidthSpinBox->value();
}

int SettingsWindow::getBombsQuantity() const
{
    return bombsQuantitySpinBox->value();
}

void SettingsWindow::changeLanguage(int index)
{
    QString languageCode = languageComboBox->currentData().toString();
    emit languageChanged(languageCode);
}

void SettingsWindow::retranslateUi()
{
    startButton->setText(tr("Start"));
    cancelButton->setText(tr("Cancel"));
    boardHeight->setText(tr("Board Height") + ":");
    boardWidth->setText(tr("Board Width") + ":");
    bombsQuantity->setText(tr("Bombs Quantity") + ":");
    language->setText(tr("Language") + ":");
}

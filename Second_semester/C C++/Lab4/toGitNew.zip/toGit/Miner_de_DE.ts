<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE">
<context>
    <name>Board</name>
    <message>
        <location filename="Board.cpp" line="178"/>
        <location filename="Board.cpp" line="184"/>
        <source>Game Rules</source>
        <translation>Spielregeln</translation>
    </message>
    <message>
        <location filename="Board.cpp" line="184"/>
        <source>Minesweeper Rules:

1. Uncover a mine, and the game ends.
2. Uncover an empty square, and you keep playing.
3. Uncover a number, and it tells you how many mines lay hidden in the eight surrounding squares.

Good luck!</source>
        <translation>Minesweeper-Regeln:

1. Decken Sie eine Mine auf und das Spiel endet.
2. Decken Sie ein leeres Feld auf und spielen Sie weiter.
3. Decken Sie eine Zahl auf, die Ihnen sagt, wie viele Minen in den acht umliegenden Feldern versteckt sind.

Viel Glück!</translation>
    </message>
    <message>
        <location filename="Board.cpp" line="437"/>
        <source>Game Over</source>
        <translation>Spiel vorbei</translation>
    </message>
    <message>
        <location filename="Board.cpp" line="437"/>
        <source>You hit a bomb! Game over.</source>
        <translation>Du hast eine Bombe getroffen! Spiel vorbei.</translation>
    </message>
    <message>
        <location filename="Board.cpp" line="454"/>
        <source>Congrats</source>
        <translation>Glückwunsch</translation>
    </message>
    <message>
        <location filename="Board.cpp" line="454"/>
        <source>You won</source>
        <translation>Du hast gewonnen</translation>
    </message>
</context>
<context>
    <name>RestartWindow</name>
    <message>
        <location filename="RestartWindow.cpp" line="5"/>
        <source>Restart Game</source>
        <translation>Spiel neustarten</translation>
    </message>
    <message>
        <location filename="RestartWindow.cpp" line="7"/>
        <source>Try Again</source>
        <translation>Versuchen Sie es erneut</translation>
    </message>
    <message>
        <location filename="RestartWindow.cpp" line="10"/>
        <source>Go to Settings</source>
        <translation>Einstellungen</translation>
    </message>
    <message>
        <location filename="RestartWindow.cpp" line="13"/>
        <source>Resume</source>
        <translation>Wieder aufnehmen</translation>
    </message>
</context>
<context>
    <name>SettingsWindow</name>
    <message>
        <location filename="SettingsWindow.cpp" line="46"/>
        <location filename="SettingsWindow.cpp" line="105"/>
        <source>Board Height</source>
        <translation>Bretthöhe</translation>
    </message>
    <message>
        <location filename="SettingsWindow.cpp" line="47"/>
        <location filename="SettingsWindow.cpp" line="106"/>
        <source>Board Width</source>
        <translation>Brettbreite</translation>
    </message>
    <message>
        <location filename="SettingsWindow.cpp" line="48"/>
        <location filename="SettingsWindow.cpp" line="107"/>
        <source>Bombs Quantity</source>
        <translation>Bombenmenge</translation>
    </message>
    <message>
        <location filename="SettingsWindow.cpp" line="49"/>
        <location filename="SettingsWindow.cpp" line="108"/>
        <source>Language</source>
        <translation>Sprache</translation>
    </message>
    <message>
        <location filename="SettingsWindow.cpp" line="32"/>
        <location filename="SettingsWindow.cpp" line="103"/>
        <source>Start</source>
        <translation>Start</translation>
    </message>
    <message>
        <location filename="SettingsWindow.cpp" line="39"/>
        <location filename="SettingsWindow.cpp" line="104"/>
        <source>Cancel</source>
        <translation>Stornieren</translation>
    </message>
</context>
</TS>

<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="hi_IN">
<context>
    <name>Board</name>
    <message>
        <location filename="Board.cpp" line="178"/>
        <location filename="Board.cpp" line="184"/>
        <source>Game Rules</source>
        <translation>खेल के नियमों</translation>
    </message>
    <message>
        <location filename="Board.cpp" line="184"/>
        <source>Minesweeper Rules:

1. Uncover a mine, and the game ends.
2. Uncover an empty square, and you keep playing.
3. Uncover a number, and it tells you how many mines lay hidden in the eight surrounding squares.

Good luck!</source>
        <translation>माइनस्वीपर नियम:

1. एक खदान को उजागर करें, और खेल समाप्त हो जाएगा।
2. एक खाली वर्ग को उजागर करें, और आप खेलना जारी रखें।
3. एक नंबर उजागर करें, और यह आपको बताता है कि आसपास के आठ चौकों में कितनी खदानें छिपी हुई हैं।

आपको कामयाबी मिले!</translation>
    </message>
    <message>
        <location filename="Board.cpp" line="437"/>
        <source>Game Over</source>
        <translation>खेल खत्म</translation>
    </message>
    <message>
        <location filename="Board.cpp" line="437"/>
        <source>You hit a bomb! Game over.</source>
        <translation>तुमने बम मारा! खेल खत्म।</translation>
    </message>
    <message>
        <location filename="Board.cpp" line="454"/>
        <source>Congrats</source>
        <translation>बधाई</translation>
    </message>
    <message>
        <location filename="Board.cpp" line="454"/>
        <source>You won</source>
        <translation>आप जीते</translation>
    </message>
</context>
<context>
    <name>RestartWindow</name>
    <message>
        <location filename="RestartWindow.cpp" line="5"/>
        <source>Restart Game</source>
        <translation>पुनः खेल प्रारंभ करें</translation>
    </message>
    <message>
        <location filename="RestartWindow.cpp" line="7"/>
        <source>Try Again</source>
        <translation>पुनः प्रयास करें</translation>
    </message>
    <message>
        <location filename="RestartWindow.cpp" line="10"/>
        <source>Go to Settings</source>
        <translation>सेटिंग्स में जाओ</translation>
    </message>
    <message>
        <location filename="RestartWindow.cpp" line="13"/>
        <source>Resume</source>
        <translation>फिर शुरू करना</translation>
    </message>
</context>
<context>
    <name>SettingsWindow</name>
    <message>
        <source>Change Language</source>
        <translation type="vanished">भाषा बदलें</translation>
    </message>
    <message>
        <location filename="SettingsWindow.cpp" line="46"/>
        <location filename="SettingsWindow.cpp" line="105"/>
        <source>Board Height</source>
        <translation>बोर्ड की ऊंचाई</translation>
    </message>
    <message>
        <location filename="SettingsWindow.cpp" line="47"/>
        <location filename="SettingsWindow.cpp" line="106"/>
        <source>Board Width</source>
        <translation>बोर्ड की चौड़ाई</translation>
    </message>
    <message>
        <location filename="SettingsWindow.cpp" line="48"/>
        <location filename="SettingsWindow.cpp" line="107"/>
        <source>Bombs Quantity</source>
        <translation>बमों की मात्रा</translation>
    </message>
    <message>
        <location filename="SettingsWindow.cpp" line="49"/>
        <location filename="SettingsWindow.cpp" line="108"/>
        <source>Language</source>
        <translation>भाषा</translation>
    </message>
    <message>
        <location filename="SettingsWindow.cpp" line="32"/>
        <location filename="SettingsWindow.cpp" line="103"/>
        <source>Start</source>
        <translation>शुरू</translation>
    </message>
    <message>
        <location filename="SettingsWindow.cpp" line="39"/>
        <location filename="SettingsWindow.cpp" line="104"/>
        <source>Cancel</source>
        <translation>रद्द करना</translation>
    </message>
</context>
</TS>

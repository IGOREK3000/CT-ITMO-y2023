#include "Button.h"

Button::Button(int row, int col, QWidget *parent) :
    QPushButton(parent), inner_state(Empty), outer_state(Hidden), row(row), col(col)
{
    setFixedSize(50, 50);
}

Button::Button(int row, int col, int8_t inner_state, int8_t outer_state, QWidget *parent) :
    QPushButton(parent), inner_state(inner_state), outer_state(outer_state), row(row), col(col)
{
}

int8_t Button::getInnerState() const
{
    return inner_state;
}

void Button::setInnerState(int8_t state)
{
    inner_state = state;
}

int8_t Button::getOuterState() const
{
    return outer_state;
}

void Button::setOuterState(Button::OuterState state)
{
    outer_state = state;
}

void Button::setOuterState(int8_t state)
{
    outer_state = state;
}

void Button::open()
{
    outer_state = Opened;
}

void Button::close()
{
    outer_state = Hidden;
}

void Button::setEmpty()
{
    inner_state = Empty;
}

void Button::incInnerState()
{
    if (inner_state != Bomb)
    {
        ++inner_state;
    }
}

bool Button::isOpened()
{
    return outer_state == Opened;
}
bool Button::isEmpty()
{
    return inner_state == Empty;
}
bool Button::isHidden()
{
    return outer_state == Hidden;
};
bool Button::isFlag()
{
    return outer_state == Flagged;
}
bool Button::isQuestion()
{
    return outer_state == Questioned;
}

void Button::mousePressEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton)
    {
        emit leftClicked(row, col);
    }
    else if (event->button() == Qt::RightButton)
    {
        emit rightClicked(row, col);
    }
    else if (event->button() == Qt::MiddleButton)
    {
        emit middleClicked(row, col);
    }
    QPushButton::mousePressEvent(event);
}

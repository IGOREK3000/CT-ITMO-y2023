#pragma once

#include <QComboBox>
#include <QDialog>
#include <QLabel>
#include <QPushButton>
#include <QSpinBox>
#include <QTranslator>
#include <QVBoxLayout>

class SettingsWindow : public QDialog
{
    Q_OBJECT

public:
    explicit SettingsWindow(QWidget *parent = nullptr);
    int getBoardHeight() const;
    int getBoardWidth() const;
    int getBombsQuantity() const;
    void retranslateUi();

signals:
    void accepted();
    void rejected();
    void languageChanged(const QString &language);
    void settingsLoaded(int boardHeight, int boardWidth, int bombsQuantity);

private slots:
    void changeLanguage(int index);
    void updateBombsQuantityLimit();

private:
    QComboBox *languageComboBox;
    QSpinBox *boardHeightSpinBox;
    QSpinBox *boardWidthSpinBox;
    QSpinBox *bombsQuantitySpinBox;
    QPushButton *startButton;
    QPushButton *cancelButton;
    QLabel *boardHeight;
    QLabel *boardWidth;
    QLabel *bombsQuantity;
    QLabel *language;
};

#pragma once

#include <QDebug>
#include <QMouseEvent>
#include <QPushButton>

class Button : public QPushButton
{
    Q_OBJECT

public:
    enum OuterState : int8_t
    {
        Hidden = 9,
        Flagged = 10,
        Exploded = 11,
        Questioned = 12,
        Opened = 13
    };

    enum InnerState : int8_t
    {
        Empty = 0,
        Bomb = -1
    };

    Button(int row, int col, QWidget *parent = nullptr);

    Button(int row, int col, int8_t inner_state, int8_t outer_state, QWidget *parent = nullptr);

    int8_t getInnerState() const;
    void setInnerState(int8_t state);

    int8_t getOuterState() const;
    void setOuterState(OuterState state);
    void setOuterState(int8_t state);

    void incInnerState();

    void open();
    void close();
    void setEmpty();

    bool isOpened();
    bool isEmpty();
    bool isHidden();
    bool isFlag();
    bool isQuestion();

signals:
    void leftClicked(int row, int col);
    void rightClicked(int row, int col);
    void middleClicked(int row, int col);

protected:
    void mousePressEvent(QMouseEvent *event) override;

private:
    int8_t inner_state;
    int8_t outer_state;
    int row;
    int col;
};

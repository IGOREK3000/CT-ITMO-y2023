#include "Board.h"
#include "Button.h"

#include <QApplication>
#include <QDebug>
#include <QMessageBox>
#include <QRandomGenerator>
#include <QSettings>
#include <QToolBar>

Board::Board(int height, int width, int bombsQuantity, bool dbg, QMainWindow *parent) :
    QMainWindow(parent), boardWidth(width), boardHeight(height), bombsQuantity(bombsQuantity),
    hiddenQuantity(boardWidth * boardHeight), gameState(-2), resize_flag(false)
{
    loadImages();
    initStateIconMap();

    createToolBar(dbg);
    createGridLayout();

    combineLayouts();
}

Board::Board(bool dbg, QMainWindow *parent) : Board(10, 10, dbg, parent) {}

void Board::retranslateUi() {}

void Board::closeEvent(QCloseEvent *event)
{
    QSettings settings("Igor", "MineSweeper");
    if (gameState != 0)
    {
        settings.clear();
        QMainWindow::closeEvent(event);
        return;
    }
    settings.setValue("boardWidth", boardWidth);
    settings.setValue("boardHeight", boardHeight);
    settings.setValue("bombsQuantity", bombsQuantity);
    settings.setValue("hiddenQuantity", hiddenQuantity);
    settings.setValue("gameState", gameState);
    settings.beginWriteArray("boardState");
    for (int r = 0; r < boardHeight; ++r)
    {
        settings.setArrayIndex(r);
        settings.beginWriteArray("row");
        for (int c = 0; c < boardWidth; ++c)
        {
            settings.setArrayIndex(c);
            settings.setValue("innerState", buttons[r][c]->getInnerState());
            settings.setValue("outerState", buttons[r][c]->getOuterState());
        }
        settings.endArray();
    }
    settings.endArray();

    QMainWindow::closeEvent(event);
}

void Board::resizeEvent(QResizeEvent *event)
{
    QMainWindow::resizeEvent(event);
    int availableSize = qMin(event->size().width(), event->size().height());

    qreal scaleFactor = 0.85;
    gridLayout->setContentsMargins(0, 0, 0, 0);

    if (boardWidth > boardHeight)
    {
        this->resize(availableSize, availableSize * boardHeight / boardWidth);
    }
    else
    {
        this->resize(availableSize * boardWidth / boardHeight, availableSize);
    }

    int scaledButtonSize = qMin(width() / boardWidth * scaleFactor, height() / boardHeight * scaleFactor);

    for (int row = 0; row < boardHeight; ++row)
    {
        for (int col = 0; col < boardWidth; ++col)
        {
            buttons[row][col]->setIconSize(QSize(scaledButtonSize, scaledButtonSize));
            buttons[row][col]->setFixedSize(scaledButtonSize, scaledButtonSize);
        }
    }
}

void Board::restoreBoardState()
{
    QSettings settings("Igor", "MineSweeper");
    int savedBoardWidth = settings.value("boardWidth", 5).toInt();
    int savedBoardHeight = settings.value("boardHeight", 5).toInt();
    int savedBombsQuantity = settings.value("bombsQuantity", 5).toInt();
    int savedHiddenQuantity = settings.value("hiddenQuantity", 25).toInt();
    int savedGameState = settings.value("gameState", -2).toInt();

    resetBoard();

    boardWidth = savedBoardWidth;
    boardHeight = savedBoardHeight;
    bombsQuantity = savedBombsQuantity;
    hiddenQuantity = savedHiddenQuantity;
    gameState = savedGameState;

    settings.beginReadArray("boardState");
    for (int r = 0; r < boardHeight; ++r)
    {
        settings.setArrayIndex(r);
        settings.beginReadArray("row");
        for (int c = 0; c < boardWidth; ++c)
        {
            settings.setArrayIndex(c);
            int8_t innerState = settings.value("innerState").toInt();
            int8_t outerState = settings.value("outerState").toInt();
            buttons[r][c]->setInnerState(innerState);
            buttons[r][c]->setOuterState(outerState);

            if (buttons[r][c]->isOpened())
            {
                buttons[r][c]->setIcon(stateIconMap[innerState]);
            }
            else
            {
                buttons[r][c]->setIcon(stateIconMap[outerState]);
            }
        }

        settings.endArray();
    }
    settings.endArray();
}

void Board::createToolBar(bool dbg)
{
    toolBar = new QToolBar(this);
    addToolBar(Qt::TopToolBarArea, toolBar);

    QPushButton *extraButton = new QPushButton(this);
    extraButton->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    extraButton->setIconSize(extraButton->size());
    extraButton->setIcon(ExtraButton);
    connect(extraButton, &QPushButton::clicked, this, &Board::handleExtraButtonClicked);

    QWidget *spacer = new QWidget(this);
    spacer->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    toolBar->addWidget(spacer);

    toolBar->addWidget(extraButton);

    QWidget *spacer2 = new QWidget(this);
    spacer2->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    toolBar->addWidget(spacer2);

    if (dbg)
    {
        dbgButton = new QPushButton(this);
        dbgButton->setCheckable(true);
        dbgButton->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        dbgButton->setIcon(DbgButtonOff);
        dbgButton->setIconSize(dbgButton->size());
        connect(dbgButton, &QPushButton::toggled, this, &Board::handleDbgButtonToggled);

        QVBoxLayout *dbgLayout = new QVBoxLayout();
        dbgLayout->addStretch();
        dbgLayout->addWidget(dbgButton);

        QWidget *dbgWidget = new QWidget(this);
        dbgWidget->setLayout(dbgLayout);
        toolBar->addWidget(dbgWidget);
    }

    QAction *rulesAction = toolBar->addAction(tr("Game Rules"));
    connect(rulesAction, &QAction::triggered, this, &Board::showGameRules);
}

void Board::showGameRules()
{
    QMessageBox::information(
        this,
        tr("Game Rules"),
        tr("Minesweeper Rules:\n\n"
           "1. Uncover a mine, and the game ends.\n"
           "2. Uncover an empty square, and you keep playing.\n"
           "3. Uncover a number, and it tells you how many mines lay hidden in the eight surrounding squares.\n\n"
           "Good luck!"));
}

void Board::createGridLayout()
{
    gridLayout = new QGridLayout();
    gridLayout->setSpacing(5);

    int buttonSize = qMin(width() / boardWidth, height() / boardHeight) * 0.93;

    for (int row = 0; row < boardHeight; ++row)
    {
        buttons.append(QVector< Button * >());
        for (int col = 0; col < boardWidth; ++col)
        {
            Button *button = new Button(row, col, this);
            button->setIcon(stateIconMap[Button::Hidden]);
            button->setFixedHeight(buttonSize);
            button->setFixedWidth(buttonSize);
            button->setIconSize(QSize(buttonSize, buttonSize));
            gridLayout->addWidget(button, row, col);
            buttons[row].append(button);
            connect(button, &Button::leftClicked, this, &Board::handleLeftButtonClick);
            connect(button, &Button::rightClicked, this, &Board::handleRightButtonClick);
            connect(button, &Button::middleClicked, this, &Board::handleMiddleButtonClick);
        }
    }
}

void Board::combineLayouts()
{
    QWidget *centralWidget = new QWidget(this);
    setCentralWidget(centralWidget);

    QVBoxLayout *mainLayout = new QVBoxLayout(centralWidget);
    mainLayout->addWidget(toolBar);
    mainLayout->addLayout(gridLayout);
}

void Board::resetBoard()
{
    resetButtons();
    notOpened.clear();
    this->hiddenQuantity = boardHeight * boardWidth;
    this->gameState = -2;
}

void Board::resetButtons()
{
    for (auto &row : buttons)
    {
        for (Button *button : row)
        {
            button->setIcon(Hidden);
            button->setOuterState(Button::Hidden);
            button->setEmpty();
        }
    }
}

void Board::loadImages()
{
    Hidden = QIcon(":images/images/hidden.png");
    Flag = QIcon(":images/images/flag.png");
    BombImage = QIcon(":images/images/bomb.png");
    BombExploded = QIcon(":images/images/bombExploded.jpg");
    Empty = QIcon(":images/images/empty.png");
    Question = QIcon(":images/images/question.jpg");
    DbgButtonOff = QIcon(":images/images/magnifyingGlass1.png");
    DbgButtonOn = QIcon(":images/images/magnifyingGlass2.png");
    ExtraButton = QIcon(":images/images/scarySmile.png");
    N1 = QIcon(":images/images/one.png");
    N2 = QIcon(":images/images/two.png");
    N3 = QIcon(":images/images/three.png");
    N4 = QIcon(":images/images/four.png");
    N5 = QIcon(":images/images/five.png");
    N6 = QIcon(":images/images/six.png");
    N7 = QIcon(":images/images/seven.png");
    N8 = QIcon(":images/images/eight.png");
}

void Board::initStateIconMap()
{
    stateIconMap[Button::Hidden] = Hidden;
    stateIconMap[Button::Flagged] = Flag;
    stateIconMap[Button::Empty] = Empty;
    stateIconMap[Button::Bomb] = BombImage;
    stateIconMap[Button::Exploded] = BombExploded;
    stateIconMap[Button::Questioned] = Question;
    stateIconMap[1] = N1;
    stateIconMap[2] = N2;
    stateIconMap[3] = N3;
    stateIconMap[4] = N4;
    stateIconMap[5] = N5;
    stateIconMap[6] = N6;
    stateIconMap[7] = N7;
    stateIconMap[8] = N8;
    stateIconMap[13] = DbgButtonOn;
    stateIconMap[14] = DbgButtonOff;
}

void Board::handleLeftButtonClick(int row, int col)
{
    if (gameState == -2)
    {
        gameState = 0;
        initInnerState(row, col, bombsQuantity);
    }
    cleverOpenCell(row, col);
}

void Board::handleRightButtonClick(int row, int col)
{
    if (!buttons[row][col]->isOpened() && !buttons[row][col]->isFlag())
    {
        setFlag(row, col);
    }
    else if (buttons[row][col]->isFlag())
    {
        removeFlag(row, col);
    }
}

void Board::handleMiddleButtonClick(int row, int col)
{
    if (!buttons[row][col]->isOpened() || buttons[row][col]->isEmpty())
    {
        return;
    }
    if (countFlags(row, col) == buttons[row][col]->getInnerState())
    {
        openKnownCellsAround(row, col);
    }
    else
    {
        markUnknownCellsAround(row, col);
    }
}

void Board::handleDbgButtonToggled(bool checked)
{
    if (gameState != 0)
    {
        return;
    }
    if (checked)
    {
        dbgButton->setIcon(DbgButtonOn);
        for (int r = 0; r < boardHeight; r++)
        {
            for (int c = 0; c < boardWidth; c++)
            {
                if (!buttons[r][c]->isOpened())
                {
                    notOpened.insert(qMakePair(r, c), buttons[r][c]->getOuterState());
                    openSingleCell(r, c);
                    hiddenQuantity++;
                }
            }
        }
    }
    else
    {
        dbgButton->setIcon(DbgButtonOff);
        for (auto it = notOpened.begin(); it != notOpened.end(); ++it)
        {
            int r = it.key().first;
            int c = it.key().second;
            buttons[r][c]->setOuterState(it.value());
            buttons[r][c]->setIcon(stateIconMap[it.value()]);
        }
        notOpened.clear();
    }
}

void Board::handleExtraButtonClicked()
{
    emit extraButtonClicked();
}

bool Board::inBoard(int row, int col)
{
    return row >= 0 && row < boardHeight && col >= 0 && col < boardWidth;
}

void Board::openSingleCell(int row, int col)
{
    buttons[row][col]->open();
    buttons[row][col]->setIcon(stateIconMap[buttons[row][col]->getInnerState()]);
    hiddenQuantity--;
}

void Board::closeSingleCell(int row, int col)
{
    buttons[row][col]->close();
    buttons[row][col]->setIcon(stateIconMap[Button::Hidden]);
}

void Board::setFlag(int row, int col)
{
    buttons[row][col]->setOuterState(Button::Flagged);
    buttons[row][col]->setIcon(stateIconMap[Button::Flagged]);
}

void Board::removeFlag(int row, int col)
{
    buttons[row][col]->close();
    buttons[row][col]->setIcon(stateIconMap[Button::Hidden]);
}

void Board::setQuestion(int row, int col)
{
    buttons[row][col]->setOuterState(Button::Questioned);
    buttons[row][col]->setIcon(stateIconMap[Button::Questioned]);
}

bool Board::hasHidden()
{
    return hiddenQuantity > bombsQuantity;
}

void Board::openEmptyNeighbours(int row, int col)
{
    if (!inBoard(row, col) || buttons[row][col]->isOpened())
    {
        return;
    }
    openSingleCell(row, col);

    if (!buttons[row][col]->isEmpty())
    {
        return;
    }

    for (const auto &n : neighbors)
    {
        openEmptyNeighbours(row + n.first, col + n.second);
    }
}

void Board::cleverOpenCell(int row, int col)
{
    int8_t innerState = buttons[row][col]->getInnerState();
    if (innerState == Button::Bomb)
    {
        openSingleCell(row, col);
        buttons[row][col]->setIcon(stateIconMap[Button::Exploded]);
        gameState = -1;
        openAllCells();
        QMessageBox::information(this, tr("Game Over"), tr("You hit a bomb! Game over."));
        emit gameEnded();
        return;
    }
    else if (innerState == Button::Empty)
    {
        openEmptyNeighbours(row, col);
    }
    else if (innerState != Button::Flagged)
    {
        openSingleCell(row, col);
    }

    if (!hasHidden())
    {
        gameState = 1;
        openAllCells();
        QMessageBox::information(this, tr("Congrats"), tr("You won"));
        emit gameEnded();
    }
}

int Board::countFlags(int row, int col)
{
    int count = 0;
    for (const auto &n : neighbors)
    {
        int r = row + n.first;
        int c = col + n.second;
        if (inBoard(r, c) && buttons[r][c]->isFlag())
        {
            count++;
        }
    }
    return count;
}

bool Board::hasQuestionCellsAround(int row, int col)
{
    for (const auto &n : neighbors)
    {
        int r = row + n.first;
        int c = col + n.second;
        if (inBoard(r, c) && buttons[r][c]->isQuestion())
        {
            return true;
        }
    }
    return false;
}

void Board::openKnownCellsAround(int row, int col)
{
    for (const auto &n : neighbors)
    {
        int r = row + n.first;
        int c = col + n.second;
        if (inBoard(r, c) && !buttons[r][c]->isOpened() && !buttons[r][c]->isFlag())
        {
            cleverOpenCell(r, c);
        }
    }
}

void Board::markUnknownCellsAround(int row, int col)
{
    bool hasQuestion = hasQuestionCellsAround(row, col);
    for (const auto &n : neighbors)
    {
        int r = row + n.first;
        int c = col + n.second;
        if (hasQuestion && inBoard(r, c) && buttons[r][c]->isQuestion())
        {
            closeSingleCell(r, c);
        }
        if (!hasQuestion && inBoard(r, c) && buttons[r][c]->isHidden())
        {
            setQuestion(r, c);
        }
    }
}

void Board::initInnerState(int row_start, int col_start, int bombsQuantity)
{
    QSet< QPair< int, int > > bombSet;
    while (bombSet.size() < bombsQuantity)
    {
        int row = QRandomGenerator::global()->bounded(boardHeight);
        int col = QRandomGenerator::global()->bounded(boardWidth);
        if ((row != row_start || col != col_start) && !bombSet.contains(qMakePair(row, col)))
        {
            buttons[row][col]->setInnerState(Button::Bomb);
            incCellsAround(row, col);
            bombSet.insert(qMakePair(row, col));
        }
    }
}

void Board::incCell(int row, int col)
{
    if (inBoard(row, col))
    {
        buttons[row][col]->incInnerState();
    }
}

void Board::incCellsAround(int row, int col)
{
    for (const auto &n : neighbors)
    {
        incCell(row + n.first, col + n.second);
    }
}

void Board::openAllCells()
{
    for (int r = 0; r < boardHeight; ++r)
    {
        for (int c = 0; c < boardWidth; ++c)
        {
            if (!buttons[r][c]->isOpened())
            {
                openSingleCell(r, c);
            }
        }
    }
}

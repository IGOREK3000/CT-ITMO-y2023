#include "RestartWindow.h"

RestartWindow::RestartWindow(QWidget *parent) : QDialog(parent)
{
    setWindowTitle(tr("Restart Game"));

    tryAgainButton = new QPushButton(tr("Try Again"), this);
    connect(tryAgainButton, &QPushButton::clicked, this, &RestartWindow::tryAgainClicked);

    goToSettingsButton = new QPushButton(tr("Go to Settings"), this);
    connect(goToSettingsButton, &QPushButton::clicked, this, &RestartWindow::backToSettingsClicked);

    resumeButton = new QPushButton(tr("Resume"), this);
    connect(resumeButton, &QPushButton::clicked, this, &RestartWindow::resumeClicked);

    QVBoxLayout *layout = new QVBoxLayout(this);
    layout->addWidget(tryAgainButton);
    layout->addWidget(goToSettingsButton);
    layout->addWidget(resumeButton);

    setLayout(layout);
}

#include "Board.h"
#include "RestartWindow.h"
#include "SettingsWindow.h"

#include <QApplication>
#include <QMessageBox>
#include <QObject>
#include <QSettings>
#include <QTranslator>

void handleGameEnd(Board *&board, SettingsWindow &settingsWindow, bool dbg);
void setupRestartWindow(RestartWindow *restartWindow, Board *&board, SettingsWindow &settingsWindow, bool dbg);
void startNewGame(Board *&board, SettingsWindow &settingsWindow, bool dbg, bool restore = false);

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    QTranslator translator;

    if (translator.load(":translations/Miner_ru_RU"))
    {
        app.installTranslator(&translator);
    }

    SettingsWindow settingsWindow;
    Board *board = nullptr;

    bool dbg = false;
    if (argc > 1 && QString(argv[1]).compare("dbg", Qt::CaseInsensitive) == 0)
    {
        dbg = true;
    }

    QObject::connect(
        &settingsWindow,
        &SettingsWindow::accepted,
        [&board, &settingsWindow, dbg]() { startNewGame(board, settingsWindow, dbg); });

    QObject::connect(&settingsWindow, &SettingsWindow::rejected, [&app]() { app.quit(); });

    QObject::connect(
        &settingsWindow,
        &SettingsWindow::languageChanged,
        [&translator, &app, &settingsWindow](const QString &languageCode)
        {
            app.removeTranslator(&translator);

            if (translator.load(":translations/Miner_" + languageCode))
            {
                app.installTranslator(&translator);
                settingsWindow.retranslateUi();
            }
        });

    QSettings settings("Igor", "MineSweeper");
    if (!settings.allKeys().isEmpty())
    {
        board =
            new Board(settings.value("boardHeight", 5).toInt(), settings.value("boardWidth", 5).toInt(), settingsWindow.getBombsQuantity(), dbg);
        board->setWindowTitle("Minesweeper");

        board->restoreBoardState();
        board->show();
        startNewGame(board, settingsWindow, dbg, true);
    }
    else
    {
        settingsWindow.show();
    }

    return app.exec();
}

void startNewGame(Board *&board, SettingsWindow &settingsWindow, bool dbg, bool restore)
{
    int height = settingsWindow.getBoardHeight();
    int width = settingsWindow.getBoardWidth();
    int bombs = settingsWindow.getBombsQuantity();

    if (!restore && board)
    {
        board->deleteLater();
        board = new Board(height, width, bombs, dbg);
    }
    else if (!restore)
    {
        board = new Board(height, width, bombs, dbg);
    }
    board->setWindowTitle("Minesweeper");
    board->show();

    QObject::connect(
        board,
        &Board::extraButtonClicked,
        [&settingsWindow, &board, dbg]()
        {
            RestartWindow *restartWindow = new RestartWindow();
            setupRestartWindow(restartWindow, board, settingsWindow, dbg);
            restartWindow->exec();
        });

    QObject::connect(
        board,
        &Board::gameEnded,
        [&settingsWindow, &board, dbg]() { handleGameEnd(board, settingsWindow, dbg); });
}

void handleGameEnd(Board *&board, SettingsWindow &settingsWindow, bool dbg)
{
    RestartWindow *restartWindow = new RestartWindow();

    QSettings settings("Igor", "MineSweeper");
    settings.clear();

    setupRestartWindow(restartWindow, board, settingsWindow, dbg);

    restartWindow->exec();
}

void setupRestartWindow(RestartWindow *restartWindow, Board *&board, SettingsWindow &settingsWindow, bool dbg)
{
    QSettings settings("Igor", "MineSweeper");
    settings.clear();
    QObject::connect(
        restartWindow,
        &RestartWindow::tryAgainClicked,
        [restartWindow, &settingsWindow, &board, dbg]()
        {
            restartWindow->close();
            restartWindow->deleteLater();
            board->close();
            board->resetBoard();
            board->show();
        });

    QObject::connect(
        restartWindow,
        &RestartWindow::backToSettingsClicked,
        [restartWindow, &settingsWindow, &board]()
        {
            restartWindow->close();
            restartWindow->deleteLater();
            if (board)
            {
                board->close();
                board->deleteLater();
                board = nullptr;
            }
            settingsWindow.show();
        });

    QObject::connect(
        restartWindow,
        &RestartWindow::resumeClicked,
        [restartWindow, &settingsWindow, &board]() { restartWindow->close(); });
}

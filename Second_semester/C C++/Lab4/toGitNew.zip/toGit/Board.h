#pragma once

#include "Button.h"
#include "QMainWindow"

#include <QGridLayout>
#include <QMap>
#include <QToolBar>
#include <QVector>
#include <QWidget>

class Board : public QMainWindow
{
    Q_OBJECT

public:
    Board(bool dbg = false, QMainWindow *parent = nullptr);
    Board(int height, int width, int bombsQuantity, bool dbg = false, QMainWindow *parent = nullptr);
    void createBoard(int height, int width, int bombsQuantity, bool dbg = false);
    void clearBoard();
    void resetBoard();
    void restoreBoardState();

protected:
    void closeEvent(QCloseEvent *event) override;
    void resizeEvent(QResizeEvent *event) override;

signals:
    void gameEnded();
    void extraButtonClicked();

private slots:
    void handleLeftButtonClick(int row, int col);
    void handleRightButtonClick(int row, int col);
    void handleMiddleButtonClick(int row, int col);
    void handleExtraButtonClicked();
    void handleDbgButtonToggled(bool checked);

private:
    QIcon Hidden, Flag, BombImage, BombExploded, Empty, Question, DbgButtonOff, DbgButtonOn, ExtraButton;
    QIcon N1, N2, N3, N4, N5, N6, N7, N8;
    int boardWidth;
    int boardHeight;
    int bombsQuantity;
    int hiddenQuantity;
    int gameState;
    bool resize_flag;
    QMap< int8_t, QIcon > stateIconMap;
    QToolBar *toolBar;
    QPushButton *dbgButton;
    QGridLayout *gridLayout;
    QVector< QVector< Button * > > buttons;
    QMap< QPair< int, int >, int8_t > notOpened;

    const QVector< QPair< int, int > > neighbors = {
        qMakePair(-1, -1), qMakePair(-1, 0), qMakePair(-1, 1), qMakePair(0, -1),
        qMakePair(0, 1),   qMakePair(1, -1), qMakePair(1, 0),  qMakePair(1, 1)
    };

    void loadImages();
    void resetButtons();
    void openAllCells();
    void createToolBar(bool debug = false);
    void createGridLayout();
    void combineLayouts();
    void openEmptyNeighbours(int row, int col);
    void initInnerState(int row_start, int col_start, int numberOfBombs);
    void incCell(int row, int col);
    void incCellsAround(int row, int col);
    void initStateIconMap();
    void cleverOpenCell(int row, int col);
    void openSingleCell(int row, int col);
    void closeSingleCell(int row, int col);
    void setFlag(int row, int col);
    void removeFlag(int row, int col);
    void setQuestion(int row, int col);
    void openKnownCellsAround(int row, int col);
    void markUnknownCellsAround(int row, int col);
    void showGameRules();

    bool inBoard(int row, int col);
    bool hasQuestionCellsAround(int row, int col);
    bool hasHidden();

    int countFlags(int row, int col);
    void retranslateUi();
};

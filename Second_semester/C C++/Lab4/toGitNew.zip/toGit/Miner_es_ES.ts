<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>Board</name>
    <message>
        <location filename="Board.cpp" line="178"/>
        <location filename="Board.cpp" line="184"/>
        <source>Game Rules</source>
        <translation>Reglas del juego</translation>
    </message>
    <message>
        <location filename="Board.cpp" line="184"/>
        <source>Minesweeper Rules:

1. Uncover a mine, and the game ends.
2. Uncover an empty square, and you keep playing.
3. Uncover a number, and it tells you how many mines lay hidden in the eight surrounding squares.

Good luck!</source>
        <translation>Reglas del buscaminas:

1. Descubre una mina y el juego termina.
2. Descubre un cuadrado vacío y continúas jugando.
3. Descubre un número que te indica cuántas minas hay escondidas en los ocho cuadrados circundantes.

¡Buena suerte!</translation>
    </message>
    <message>
        <location filename="Board.cpp" line="437"/>
        <source>Game Over</source>
        <translation>Juego terminado</translation>
    </message>
    <message>
        <location filename="Board.cpp" line="437"/>
        <source>You hit a bomb! Game over.</source>
        <translation>¡Le diste a una bomba! Juego terminado.</translation>
    </message>
    <message>
        <location filename="Board.cpp" line="454"/>
        <source>Congrats</source>
        <translation>Felicitaciones</translation>
    </message>
    <message>
        <location filename="Board.cpp" line="454"/>
        <source>You won</source>
        <translation>Ganaste</translation>
    </message>
</context>
<context>
    <name>RestartWindow</name>
    <message>
        <location filename="RestartWindow.cpp" line="5"/>
        <source>Restart Game</source>
        <translation>Reinicia el juego</translation>
    </message>
    <message>
        <location filename="RestartWindow.cpp" line="7"/>
        <source>Try Again</source>
        <translation>Intentar otra vez</translation>
    </message>
    <message>
        <location filename="RestartWindow.cpp" line="10"/>
        <source>Go to Settings</source>
        <translation>Einstellungen</translation>
    </message>
    <message>
        <location filename="RestartWindow.cpp" line="13"/>
        <source>Resume</source>
        <translation>Reanudar</translation>
    </message>
</context>
<context>
    <name>SettingsWindow</name>
    <message>
        <location filename="SettingsWindow.cpp" line="46"/>
        <location filename="SettingsWindow.cpp" line="105"/>
        <source>Board Height</source>
        <translation>Altura del tablero</translation>
    </message>
    <message>
        <location filename="SettingsWindow.cpp" line="47"/>
        <location filename="SettingsWindow.cpp" line="106"/>
        <source>Board Width</source>
        <translation>Ancho del tablero</translation>
    </message>
    <message>
        <location filename="SettingsWindow.cpp" line="48"/>
        <location filename="SettingsWindow.cpp" line="107"/>
        <source>Bombs Quantity</source>
        <translation>Cantidad de bombas</translation>
    </message>
    <message>
        <location filename="SettingsWindow.cpp" line="49"/>
        <location filename="SettingsWindow.cpp" line="108"/>
        <source>Language</source>
        <translation>Idioma</translation>
    </message>
    <message>
        <location filename="SettingsWindow.cpp" line="32"/>
        <location filename="SettingsWindow.cpp" line="103"/>
        <source>Start</source>
        <translation>Comenzar</translation>
    </message>
    <message>
        <location filename="SettingsWindow.cpp" line="39"/>
        <location filename="SettingsWindow.cpp" line="104"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
</TS>
